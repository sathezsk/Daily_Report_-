package datadriven;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import jxl.read.biff.BiffException;

public class Login_Test
{
	WebDriver driver;
	  ExtentReports extentreport;
	  ExtentHtmlReporter htmlreporter;
	  ExtentTest testcase1;
	  
	@BeforeTest
	public void befourtest() throws InterruptedException
	{
		extentreport = new ExtentReports();
	    htmlreporter = new ExtentHtmlReporter("ExtentReport.html");
	    extentreport.attachReporter(htmlreporter);
		driver= new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		ExtentTest testcase1= extentreport.createTest(" verify the Login testcase");
		testcase1.log(Status.INFO, "NAVIGATING TO PixcelMind URL");
		driver.get("https://skoolgo.pixelmindit.com:5000/#/");
		Thread.sleep(5000);
	}
	
	@AfterTest
	public void aftertest() throws InterruptedException
	{
	
		Thread.sleep(5000);
		   testcase1.log(Status.INFO," == lOGIN TESTCASE SUCCESSFULLY COMPLITED ==");
		   extentreport.flush();
	       driver.quit();
	}
	
	@Test(dataProvider="logindata")
	public void loginwithbothcorrect (String uname ,String pword) throws InterruptedException, IOException
	{
		WebElement username = driver.findElement(By.id("userName"));
		username.sendKeys(uname);
		WebElement password = driver.findElement(By.id("password"));
		password.sendKeys(pword);
		WebElement login =driver.findElement(By.xpath("//button[@type='submit']"));
		login.click();
		Thread.sleep(5000);
		driver.navigate().refresh();
		
		 
		 
		 boolean name= driver.findElement(By.xpath("//h1[text()='Dashboard']")).isDisplayed();
		
		 Thread.sleep(5000);

         if(name==true)
         {
 			testcase1.log(Status.PASS,"Login Testcase is Pass");
         }
         else
         {
  			testcase1.log(Status.FAIL,"ActualResult and ExpectedResult are Not Equal");
  			testcase1.log(Status.FAIL,"Login Testcase is Fail");
      	      TakesScreenshot screenshot = (TakesScreenshot)driver;
      	      File src = (File)screenshot.getScreenshotAs(OutputType.FILE);
      	      File des = new File("testcase1.png");
      	      FileHandler.copy(src, des);
      	      testcase1.addScreenCaptureFromPath("testcase1.png");
	}
	}
	
	String [][] data =null;

	@DataProvider(name ="logindata")
	public String [][] logindataprovider() throws BiffException, IOException
	{
		data=getexceldata();
		return data;
	}
	public String[][] getexceldata() throws IOException, BiffException
	{
		FileInputStream excel = new FileInputStream("./Data/testdata.xls");
		jxl.Workbook workbook = jxl.Workbook.getWorkbook(excel);
		jxl.Sheet sheet = workbook.getSheet(0);
		int rowcount = sheet.getRows();
		int cowcount= sheet.getColumns();

		String testData[][]=new String [rowcount-1][cowcount];
		for(int i=1;i<rowcount;i++)
		{
			for(int j=0;j<cowcount;j++)
			{
				testData [i-1][j] = sheet.getCell(j,i).getContents();
			}
		}

		return testData;
	}
}
