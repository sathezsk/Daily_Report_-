package datadriven;

import java.awt.AWTException;
import java.util.concurrent.TimeUnit;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class Create_Designation 
{
	
	public static void main(String[] args) throws InterruptedException  
	{

		ExtentReports extentreport;

		ExtentHtmlReporter htmlreporter;

		ExtentTest testcase;
		
		extentreport = new ExtentReports();
		htmlreporter = new ExtentHtmlReporter("ExtentReport2.html");
		extentreport.attachReporter(htmlreporter);
	
		WebDriver driver= new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		ExtentTest testcase2= extentreport.createTest(" Add Designation Testcase Started ");
		driver.get("https://skoolgo.pixelmindit.com:5000/#/");
		Thread.sleep(5000);
		WebElement username = driver.findElement(By.id("userName"));
		username.sendKeys("admin@pixel.com");
		
		WebElement password = driver.findElement(By.id("password"));
		
		password.sendKeys("sk12345");
		testcase2.log(Status.INFO, "Entering the username successfully");
		testcase2.log(Status.INFO, "Entering the password successfully");

		WebElement login =driver.findElement(By.xpath("//button[@type='submit']"));
		login.click();
		testcase2.log(Status.INFO, "Login successfully");
		Thread.sleep(5000);
		WebElement humanResource= driver.findElement(By.xpath("//p[text()='Human Resources']"));
		WebElement adddesignation= driver.findElement(By.xpath("//a[text()='Add Designation']"));
		Actions action = new Actions(driver);
		Thread.sleep(8000);
		action.moveToElement(humanResource).click().build().perform();
		action.doubleClick(adddesignation).build().perform();
		
		Thread.sleep(5000);
		 boolean ExpectedResult =	driver.findElement(By.xpath("//td[text()='Super Admin']")).isDisplayed();
		
		 if(ExpectedResult=true)
		 {
				testcase2.log(Status.PASS, " create Designation successfully");
		 }
		 else
		 {
				testcase2.log(Status.PASS, "Actual result and Expected Result is not equal");
		 }
		 driver.quit();
		 extentreport.flush();
	}

}