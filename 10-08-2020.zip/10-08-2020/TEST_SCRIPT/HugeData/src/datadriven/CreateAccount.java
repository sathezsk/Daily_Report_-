package datadriven;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import jxl.read.biff.BiffException;

public class CreateAccount
{
	WebDriver driver;
	@BeforeTest
	public void befourtest()
	{
		driver= new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.get("https://skoolgo.pixelmindit.com:5000/#/");

		WebElement signup =driver.findElement(By.xpath("//a[text()='Sign Up']"));
		signup.click();
	}
	
	@AfterTest
	public void aftertest()
	{
		driver.quit();
	}
	
	@Test(dataProvider="logindata")
	public void loginwithbothcorrect (
			String Name ,
			String Emailid ,
			String phonenumbers,
			String personalid
			) throws InterruptedException, IOException
	{
		WebElement fullname= driver.findElement(By.id("fullName"));
		fullname.sendKeys(Name);
		WebElement emailid= driver.findElement(By.id("email"));
		emailid.sendKeys(Emailid);
		WebElement phonenumber= driver.findElement(By.id("mobile"));
		phonenumber.sendKeys(phonenumbers);
		WebElement personalId= driver.findElement(By.id("personalId"));
		personalId.sendKeys(personalid);
		Thread.sleep(5000);
		WebElement Create= driver.findElement(By.xpath("//button[text()='CREATE AN ACCOUNT']"));
		Create.click();
		driver.navigate().refresh();
		Thread.sleep(5000);
		Thread.sleep(5000);
		WebElement DOB= driver.findElement(By.xpath("//input[@class='MuiInputBase-input MuiInput-input']"));
		DOB.click();
		Thread.sleep(5000);

		WebElement year= driver.findElement(By.xpath("//h6[text()='2020']"));
		year.click();
		
		Thread.sleep(5000);
		Actions action = new Actions(driver);
		WebElement myyear= driver.findElement(By.xpath("//div[text()='1899']"));
		action.moveToElement(myyear).build().perform();
		action.doubleClick().build().perform();
			
		Thread.sleep(5000);
	
		WebElement day= driver.findElement(By.xpath("//p[text()='12']"));
		action.doubleClick(day).build().perform();
		Thread.sleep(5000);
		
		/*	Thread.sleep(5000);
		WebElement nationality= driver.findElement(By.id("nationality"));

		Select select = new Select(nationality);

		List<WebElement> options= select.getOptions();
		int fullList=options.size();
		System.out.println(fullList);

		for (WebElement webElement : options)
		{
			String text = webElement.getText();
			select.selectByVisibleText("India");
			
		}
	//	Gender selecting
		Thread.sleep(8000);
		WebElement gender= driver.findElement(By.id("gender"));

		Select selectsgender= new Select(gender);

		List<WebElement> options1= selectsgender.getOptions();

		for (WebElement webElement : options1)
		{
			String gentertext = webElement.getText();
			selectsgender.selectByVisibleText("Male");
			
		}

		// Branch selecting
		Thread.sleep(8000);
		WebElement branch= driver.findElement(By.id("branch"));

		Select selectbranch1= new Select (branch);

		List<WebElement> options2= selectbranch1.getOptions();
		int fullList2=options2.size();
		System.out.println(fullList2);

		for (WebElement webElement : options2)
		{
			String text2 = webElement.getText();
			selectbranch1.selectByVisibleText("Manama");
			
		}
		
		//Height
		Thread.sleep(5000);
		WebElement height= driver.findElement(By.id("height"));
		Thread.sleep(3000);
		height.clear();
		height.sendKeys("0");
		
		
		//weight
		Thread.sleep(5000);
		WebElement weight= driver.findElement(By.id("weight"));
		Thread.sleep(3000);
		weight.clear();
		weight.sendKeys("0");
*/	
	}
	
	String [][] data =null;

	@DataProvider(name ="logindata")
	public String [][] logindataprovider() throws BiffException, IOException
	{
		data=getexceldata();
		return data;
	}
	public String[][] getexceldata() throws IOException, BiffException
	{
		FileInputStream excel = new FileInputStream("./Data/testdata2.xls");
		jxl.Workbook workbook = jxl.Workbook.getWorkbook(excel);
		jxl.Sheet sheet = workbook.getSheet(1);
		int rowcount = sheet.getRows();
		int cowcount= sheet.getColumns();

		String testData[][]=new String [rowcount-1][cowcount];
		for(int i=1;i<rowcount;i++)
		{
			for(int j=0;j<cowcount;j++)
			{
				testData [i-1][j] = sheet.getCell(j,i).getContents();
			}
		}

		return testData;
	}
}
